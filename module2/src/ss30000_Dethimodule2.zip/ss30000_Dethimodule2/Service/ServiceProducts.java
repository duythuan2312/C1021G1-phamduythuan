package ss30000_Dethimodule2.Service;

public interface ServiceProducts {
    void addNew();
    void remove();
    void displays();
    void seach();

}
