package reponssitory;

import model.Category;

import java.util.List;

public interface CategoryInterface {
    List<Category> selectAll();

}
