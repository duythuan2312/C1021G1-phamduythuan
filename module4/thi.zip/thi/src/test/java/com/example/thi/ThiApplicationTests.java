package com.example.thi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThiApplicationTests {

    @Test
    void contextLoads() {
    }

}
