package com.example.exercise1.service;

import com.example.exercise1.model.User;

public interface UserService  {
       void save(User user);
}
