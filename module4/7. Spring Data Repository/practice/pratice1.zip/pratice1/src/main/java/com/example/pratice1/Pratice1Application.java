package com.example.pratice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pratice1Application {

    public static void main(String[] args) {
        SpringApplication.run(Pratice1Application.class, args);
    }

}
