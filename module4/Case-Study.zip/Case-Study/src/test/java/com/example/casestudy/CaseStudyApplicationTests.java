package com.example.casestudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaseStudyApplicationTests {

    @Test
    void contextLoads() {
    }

}
