package com.example.casestudy.controller;

import com.example.casestudy.dto.EmployeeDto;
import com.example.casestudy.model.Employee;
import com.example.casestudy.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class EmployController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/employee")
    public ModelAndView showEmployee(Pageable pageable){
        ModelAndView modelAndView = new ModelAndView("employee/list");
        modelAndView.addObject("employeeList",employeeService.findAll(pageable));
        return modelAndView;
    }
    @GetMapping("/create")
    public ModelAndView showcreate(){
        ModelAndView modelAndView = new ModelAndView("employee/create");
        modelAndView.addObject("create",new EmployeeDto());
        return modelAndView;
    }

    @PostMapping("/create")
    public String create(@ModelAttribute @Validated EmployeeDto employeeDto , BindingResult bindingResult, Model model){
        new EmployeeDto().validate(employeeDto,bindingResult);
        if (bindingResult.hasFieldErrors()){
            return "create";
        }else {
            Employee bookSavings = new Employee();
            BeanUtils.copyProperties(bookSavingsDto,bookSavings);
            bookSavings.setCustomer(new Customer());
            bookSavings.getCustomer().setNameCustomer(bookSavingsDto.getNameCustomer());
            model.addAttribute("message", "Thêm mới thành  công");
            iBookSavingService.save(bookSavings);
        }
        return "redirect:/list";
    }

    @GetMapping("/delete")
    public String delete(Employee employee, RedirectAttributes redirectAttributes, @RequestParam int id){
        employeeService.remove(employee);
        redirectAttributes.addFlashAttribute("message","Xóa Thành Công");
        return "redirect:/list";
    }




}
