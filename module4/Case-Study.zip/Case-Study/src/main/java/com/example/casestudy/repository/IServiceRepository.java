package com.example.casestudy.repository;

public interface IServiceRepository {
}
