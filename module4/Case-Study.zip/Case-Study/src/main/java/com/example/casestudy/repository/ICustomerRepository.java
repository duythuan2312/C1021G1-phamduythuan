package com.example.casestudy.repository;

import com.example.casestudy.model.Customer;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ICustomerRepository extends PagingAndSortingRepository<Customer,Integer> {
}
